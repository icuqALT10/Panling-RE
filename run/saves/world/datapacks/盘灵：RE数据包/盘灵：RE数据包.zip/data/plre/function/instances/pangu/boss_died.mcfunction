scoreboard players reset .system instance_pangu_tick

schedule function plre:instances/pangu/success 4.5s replace