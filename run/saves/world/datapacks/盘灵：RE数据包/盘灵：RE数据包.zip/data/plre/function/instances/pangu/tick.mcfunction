execute unless entity @a[x=2992,y=0,z=-2400,dx=271,dy=255,dz=303] run return run scoreboard players reset .system instance_pangu_tick

execute store result score .system instance_pangu_health run data get entity @e[type=panlingre:pan_gu,x=2992,y=0,z=-2400,dx=271,dy=255,dz=303,limit=1] Health 1000

execute if score .system instance_pangu_health matches 1..9 run function plre:instances/pangu/boss_died