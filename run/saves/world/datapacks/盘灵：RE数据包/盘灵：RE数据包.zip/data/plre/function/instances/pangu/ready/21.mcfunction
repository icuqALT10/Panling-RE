execute as @e[x=2992,y=0,z=-2400,dx=271,dy=255,dz=303,type=panlingre:pan_gu] in minecraft:the_end run tp @s -3000 0 -3000


schedule function plre:instances/pangu/ready/22 3t replace