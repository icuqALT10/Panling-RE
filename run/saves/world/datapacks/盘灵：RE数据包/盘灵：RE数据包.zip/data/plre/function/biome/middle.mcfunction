advancement revoke @s only plre:biome/null
advancement revoke @s only plre:biome/east
advancement revoke @s only plre:biome/west
advancement revoke @s only plre:biome/south
advancement revoke @s only plre:biome/north
advancement revoke @s only plre:biome/qian_si_gu
advancement revoke @s only plre:biome/peng_lai
advancement revoke @s only plre:biome/sheng_shan

title @s title {"translate": "biome.plre.middle"}
title @s subtitle {"translate": ""}