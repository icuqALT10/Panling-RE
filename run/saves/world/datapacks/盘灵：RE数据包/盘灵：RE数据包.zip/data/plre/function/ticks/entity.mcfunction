#怪物生成
execute if entity @s[type=marker,tag=spawn_entity] run function plre:monsters/marker

#副本
execute if score .system instance_pangu_tick matches 1 run function plre:instances/pangu/tick