# Java 实现模式

以下片段展示接口契约，不是一套可直接独立编译的库。`MultipartEntity`、`SkillTargeting`、`OrientedBoundingBox`、`SyncedEntityAnimation`、`WorldTimeAnimationController` 等是参考工程辅助类。先核对项目已有实现、映射与依赖，复用合适代码；不要重复造同名类。

## 1. 目标记录保留三个信息

```java
record Target(LivingEntity root, Entity part, Vec3 point) {
    boolean hurt(DamageSource source, float amount) {
        if (part instanceof MultipartEntity.MultipartPart child
                && root instanceof MultipartEntity multipart) {
            return multipart.hurtPart(child.getPartIndex(), source, amount);
        }
        return part.hurt(source, amount); // 普通实体或原生 PartEntity 的转发
    }
}
```

部位伤害入口不重选近战目标，但最终仍调用正常主体受伤链。不要通过直接扣 `setHealth` 绕开护盾、护甲、归属与伤害事件。

## 2. OBB 最近点

```java
Vec3 closestPoint(OBB box, Vec3 p) {
    Vec3 d = p.subtract(box.center);
    return box.center
        .add(box.axisX.scale(clamp(d.dot(box.axisX), -box.half.x, box.half.x)))
        .add(box.axisY.scale(clamp(d.dot(box.axisY), -box.half.y, box.half.y)))
        .add(box.axisZ.scale(clamp(d.dot(box.axisZ), -box.half.z, box.half.z)));
}
```

这是正交归一三轴的 OBB。轴与半长已经包含模型到世界的变换。对旋转盒使用 AABB 的 clamp 会在空角产生错误命中。

## 3. 从范围内选择部位

```java
Target inArea(LivingEntity root, Vec3 impact, AABB area) {
    Target best = null;
    double distance = Double.POSITIVE_INFINITY;
    for (Entity part : targetParts(root)) {
        if (part.isRemoved() || !box(part).intersects(area)) continue;
        Vec3 point = closestPoint(part, impact);
        double next = point.distanceToSqr(impact);
        if (next < distance) {
            best = new Target(root, part, point);
            distance = next;
        }
    }
    return best;
}
```

先限制相交部位，再找最近者。不能先选一个范围外更近部位，随后判不相交并丢弃整个主体。外层候选按 UUID 去重。

```java
for (LivingEntity root : collectMultipartRoots(level, area, caster)) {
    if (!combatTargetFilter(caster).test(root)) continue;
    Target hit = inArea(root, impact, area);
    if (hit != null) hit.hurt(originalDamageSource, damage);
}
```

## 4. 旋转前方范围检查

技能用 right/up/forward 三个正交轴定义。把每个目标 OBB 的中心偏移及三个轴变换到技能坐标，再沿用 OBB–AABB SAT：

```java
Vec3 inBasis(Vec3 v, Vec3 right, Vec3 up, Vec3 forward) {
    return new Vec3(v.dot(right), v.dot(up), v.dot(forward));
}
// localCenter = inBasis(part.center - skillCenter, ...)
// localAxisX/Y/Z = inBasis(part.axisX/Y/Z, ...)
// localOBB.intersects(new AABB(-halfWidth, -halfHeight, -halfLength,
//                             halfWidth,  halfHeight,  halfLength))
```

单纯检查部位中心或离玩家最近点是否位于长方体内，会漏掉边缘相交以及并非最近的其他部位。

## 5. 实际受击部位贯穿伤害事件

```java
private int receivingPart = -1;

protected boolean hurtSelectedPart(int part, DamageSource source, float amount) {
    int previous = receivingPart;
    receivingPart = part;
    try {
        return super.hurt(source, amount * multiplierFor(part));
    } finally {
        receivingPart = previous;
    }
}
```

提供只读 accessor 给护盾等同步事件。事件按这个部位的几何检测覆盖，不能改用受伤 root.position()。嵌套 hurt 恢复 previous，而不是一律设回 -1。异步任务需要复制作用点/部位标识，不能稍后读取已清空的上下文。

## 6. 弹道首次接触

```java
HitResult nearest = clipBlocks(from, to);
double nearestDistance = nearest.getType() == HitResult.Type.MISS
        ? Double.POSITIVE_INFINITY : from.distanceToSqr(nearest.getLocation());
for (LivingEntity root : candidatesForSegment(from, to)) {
    if (!canHit(root)) continue;
    for (Entity part : targetParts(root)) {
        Optional<Vec3> p = box(part).inflate(projectilePadding).clip(from, to);
        if (p.isPresent() && from.distanceToSqr(p.get()) < nearestDistance) {
            nearest = new EntityHitResult(part, p.get());
            nearestDistance = from.distanceToSqr(p.get());
        }
    }
}
```

示例省略具体工具签名。候选空间应覆盖整段与弹体尺寸。曲线将该 tick 的参数区间分段，按飞行顺序执行以上过程；找到首次碰撞就停止，不能又在终点结算一次。采样精度与曲率/速度/部位厚度匹配，不把参考实现的固定四段当成所有轨迹都可靠的保证。

## 7. 动作时钟与事件

```java
double seconds(float partialTick) {
    if (frozen) return 0; // 已切到指定 idle 首帧
    return Math.max(0, worldGameTime - startedAt + partialTick) / 20.0 * playbackSpeed;
}
boolean crossed(double previous, double now, double at) {
    return previous < at && now >= at;
}
boolean overlaps(double previous, double now, double from, double to) {
    return previous < to && now >= from;
}
```

同一 seconds 驱动渲染骨骼、客户端 OBB 和服务端姿态采样。网络同步冻结状态，不能只服务端暂停。持续伤害窗口还需按原有受伤间隔执行；跨窗口片段做扫掠，不能把整个动画时长当作有效窗口。

参考 `WorldTimeAnimationController` 将 speed=0 视作停用，而非保持姿态，因此本项目冻结时让控制器读固定世界时间 `startedAt`，并让共用骨骼采样返回 idle 的 0 秒。更换控制器时重新核对暂停语义。

## 8. 冻结生命周期

```java
void onFreezeStarted() {
    if (frozen) return; // 刷新持续时间不重记状态
    wasNoAi = isNoAi();
    frozen = true;     // 实际使用同步数据
    setNoAi(true);
    stopNavigationAndMotion();
    cancelQueuedTurnsAndReposition();
    finishInterruptedAttackBookkeeping();
    clearAttackWindowsAndActiveEffects();
    clearPendingFormTransitions();
    playIdleForCurrentForm();
}
void onFreezeRemoved() {
    if (!frozen) return;
    frozen = false;
    setNoAi(wasNoAi);
    restoreFormPhysics();
    beginFreshIdleRecovery();
}
```

这些方法名是职责说明。实际中断时若攻击开始已经记账，则保持历史即可，不再新增。阶段无敌需执行相应收尾。仍执行 `super.tick()` 推进效果到期，然后在自定义战斗/形态逻辑之前检查 frozen 并返回。NoAI 的原始状态必须在通用效果代码改成 true 之前捕获。

## 9. 权重抽取与前向位移

```java
int roll = random.nextInt(totalEligibleWeight);
for (Candidate c : eligible) {
    roll -= c.weight();
    if (roll < 0) return c;
}
```

候选池提前剔除最近招式和不满足范围的项。空池调整使用另一条明确规则，不通过无限重抽实现。

```java
Vec3 forward = new Vec3(-Math.sin(yawRadians), 0, Math.cos(yawRadians));
Vec3 step = forward.scale(blocksPerSecond / 20.0);
```

该式是 Minecraft yaw 的常见约定，先验证模型本地前向。不要在“直冲”里改成 `(target - position).normalize()`，那会重新产生横移或倒走。

## 10. 伤害取消顺序

```java
// 示例优先级：先阻止被冻结攻击者造成伤害。
@SubscribeEvent(priority = EventPriority.HIGHEST)
public static void cancelFrozenDamage(LivingIncomingDamageEvent event) { /* ... */ }

// 后处理有效伤害的护盾，不接收已取消事件。
@SubscribeEvent(priority = EventPriority.HIGH)
public static void absorbWithBarrier(LivingIncomingDamageEvent event) {
    if (event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return;
    // 从 receivingDamagePart 获取这次真正受击部位，再查护盾。
}
```

核对当前事件总线版本和所有相关订阅者，不只改一个处理器；保持 `/kill` 及伤害归属契约。
