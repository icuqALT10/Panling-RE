#!/usr/bin/env python3
"""Read-only Blockbench structural and animation editability audit (stdlib)."""
import argparse, collections, json, math
from pathlib import Path

def audit(d, fps=None):
    errors, warnings, tracks = [], [], []
    groups = {g['uuid']: g for g in d.get('groups', [])}
    def walk(items):
        for g in items:
            if isinstance(g, dict):
                groups.setdefault(g.get('uuid'), g)
                walk(g.get('children', []))
    walk(d.get('outliner', []))
    for a in d.get('animations', []):
        rate = fps or a.get('snapping', 20) or 20
        for uid, tr in a.get('animators', {}).items():
            if tr.get('type', 'bone') != 'bone':
                continue
            label = f"{a.get('name')}/{tr.get('name', uid)}"
            if uid not in groups:
                errors.append(label + ': animator bone UUID missing')
            seen, counts = set(), collections.Counter()
            for k in tr.get('keyframes', []):
                ch, t = k.get('channel'), k.get('time')
                if ch not in ('rotation', 'position', 'scale'):
                    errors.append(label + ': invalid bone channel ' + str(ch))
                if not isinstance(t, (float, int)) or not math.isfinite(t):
                    errors.append(label + ': invalid key time')
                    continue
                if abs(t * rate - round(t * rate)) > 1e-5:
                    warnings.append(f'{label}/{ch}: time {t} outside {rate} FPS grid')
                if (ch, t) in seen:
                    errors.append(f'{label}/{ch}: duplicate time {t}')
                seen.add((ch, t)); counts[ch] += 1
                for point in k.get('data_points', []):
                    for axis in 'xyz':
                        value = point.get(axis)
                        try:
                            number = float(value)
                        except (TypeError, ValueError):
                            continue  # Expressions are valid; do not evaluate Molang.
                        if not math.isfinite(number):
                            errors.append(f'{label}/{ch}/{axis}: nonfinite value')
            for ch, count in counts.items():
                tracks.append({'track': label + '/' + str(ch), 'keys': count})
                if count > 9:
                    warnings.append(f'{label}/{ch}: {count} keys; inspect before simplifying')
    pairs = [('west', 'east'), ('down', 'up'), ('north', 'south')]
    for e in d.get('elements', []):
        if 'from' not in e or 'to' not in e:
            continue
        faces = e.get('faces', {})
        for i, pair in enumerate(pairs):
            if abs(e['from'][i] - e['to'][i]) < 1e-7 and all(faces.get(f, {}).get('texture') is not None for f in pair):
                warnings.append(f"{e.get('name', e.get('uuid'))}: zero-thickness opposing faces {pair}; inspect overlap, do not auto-delete")
    return {'errors': errors, 'warnings': warnings, 'stats': {'bones': len(groups), 'animations': len(d.get('animations', [])), 'tracks': len(tracks), 'max_keys_per_track': max((t['keys'] for t in tracks), default=0)}, 'tracks': tracks}

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('model', type=Path); p.add_argument('--fps', type=float); p.add_argument('--report', type=Path)
    args = p.parse_args()
    if args.fps is not None and (args.fps <= 0 or not math.isfinite(args.fps)):
        p.error('--fps must be positive and finite')
    result = audit(json.loads(args.model.read_text()), args.fps)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.report:
        args.report.write_text(text + '\n')
    else:
        print(text)
    raise SystemExit(bool(result['errors']))
